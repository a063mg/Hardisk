n = int(input())
k = int(input())
n = (n + 2) // 2
k = (k + 2) // 2
print(n * k)

